﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("EB:");
            string b = Console.ReadLine();
            Console.Write("EH:");
            string h = Console.ReadLine();
            R r = new R(b, h);
            Console.WriteLine(r.ToString());
            Console.ReadKey();
        }
    }
}
