﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class R
    {
        public DateTime? B { get; private set; }
        public int? H { get; private set; }

        public R(string b,string h)
        {
            DateTime tD;
            if (DateTime.TryParse(b, out tD))
                B = tD;
            else
                B = null;
            int tI;
            if (int.TryParse(h, out tI))
                H = tI;
            else
                H = null;
        }
        public override string ToString()
        {
            string des;
            if (B != null)
                des = "I was born on" + B.Value.ToLongDateString();
            else
                des = "I don't know B";
            if (H != null)
                des += ",I am" + H;
            else
                des += ",I don't know H";
            return des;
        }
    }
}
