﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace equation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 打开系统自带的计算器
            System.Diagnostics.Process.Start("calc");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(textBox3.Text);
                if(a == 0){
                    MessageBox.Show("不是一元二次方程");

                }
                else
                {
                    double b = Convert.ToDouble(textBox2.Text);
                    double c = Convert.ToDouble(textBox1.Text);
                    double j = b * b - 4 * a * c;
                    if(j < 0)
                    {
                        MessageBox.Show("无解");
                    }
                    else
                    {
                        double s = System.Math.Sqrt(j);
                        double x1 = (-b + s) / 2 * a;
                        double x2 = (-b - s) / 2 * a;
                        MessageBox.Show("x1 = "+x1 + ","
                        +"x2 = " +x2);
                    }

                }
                    

            }
            catch (FormatException)
            {
                MessageBox.Show("错误");
            }
        }
    }
}
