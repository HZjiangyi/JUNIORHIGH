﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace clipboard
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.MaximizeBox = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Declares an IDataObject to hold the data returned from the clipboard.
            // Retrieves the data from the clipboard.
            IDataObject iData = Clipboard.GetDataObject();

            // Determines whether the data is in a format you can use.
            if (iData.GetDataPresent(DataFormats.Text))
            {
                // Yes it is, so display it in a text box.
                textBox1.Text = (String)iData.GetData(DataFormats.Text);
            }
        }

        private void textBox1_MouseEnter(object sender, EventArgs e)
        {
            this.toolTip1.ToolTipTitle = "Clipboard";
            this.toolTip1.IsBalloon = false;

            this.toolTip1.UseFading = true;

            this.toolTip1.Show("---the programmer", this.textBox1);
        }

        private void textBox1_MouseLeave(object sender, EventArgs e)
        {
            this.toolTip1.Hide(textBox1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.SelectAll();
            if (textBox1.Text != "")
                textBox1.Copy();
            else
                MessageBox.Show("The Clipboard is Empty");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            IDataObject iData = Clipboard.GetDataObject();
            if (iData.GetDataPresent(DataFormats.Text))
            {
                textBox1.Text = "";
                Clipboard.SetDataObject(textBox1.Text);
            }
        }

        private void toolStripSplitButton1_Click(object sender, EventArgs e)
        {
            string text = "Clipboard 1.0\r\nAuthor : JY\r\n E-mail :2509203371@qq.com";
            MessageBox.Show(text, "about");

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            string text = "Clipboard 1.0\r\nAuthor : JY\r\n E-mail :2509203371@qq.com";
            MessageBox.Show(text, "about");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            StreamWriter myStream;
            saveFileDialog1.Filter = "txt files(*.txt)|*.txt";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;
            

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                myStream = new StreamWriter(saveFileDialog1.FileName);
                myStream.Write(textBox1.Text); //写入
                myStream.Close();//关闭流

            }
        }
    }
}
