﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace name
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            String [] Array = new String[4];
            Array[0] = "一";
            Array[1] = "二";
            Array[0] = "三";
            Array[0] = "四";
            Array[0] = "五";
            List<String> n = new List<string>();
            string name = Array[r.Next(0, 4)] + Array[r.Next(0, 4)] + Array[r.Next(0, 4)];
            Console.WriteLine(name);
            Console.ReadKey();
        }
    }
}
